const Admin = {
  async render() {
    return `
        <section id="hero" class="hero">Admin Panel</section>
      `;
  },

  async afterRender() {
    // Implementasikan logika tambahan yang diperlukan setelah render di sini
  },
};

export { Admin };
